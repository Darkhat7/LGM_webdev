import { makeStyles } from '@material-ui/styles';

export default makeStyles(theme => ({
    progressContainer: {
        height: '5px',
        width: '100%',
        display: 'flex'
    }
}));
